function getStudnetInfo(data) {
    return data;
}
console.log(getStudnetInfo(10));

var Student = /** @class */ (function () {
    function Student(name, studentId) {
        this.attendance = 0;
        this.name = name;
        this.studentId = studentId;
    }
    Student.prototype.markAttendance = function () {
        this.attendance++;
    };
    Student.prototype.showAttendance = function () {
        console.log(this.attendance);
    };
    return Student;
}());
var s1 = new Student("tejas", 1);
s1.markAttendance();
s1.markAttendance();
s1.markAttendance();
s1.showAttendance();

// Q1 and Q2
class AgeNotValid extends Error{
    constructor(message){
        super(message)
        this.name = "AgeNotValid"
    }
}

function vote(age){
    if (age<18) {
        throw new AgeNotValid("Not eligible to vote")
    } else {
        console.log("you are eligible");
        
    }
}

vote(10)
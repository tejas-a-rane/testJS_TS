let stock = 10
class Quant extends Error{
    constructor(message){
        super(message)
        this.name = "Stock error"
    }
}

function checkQuant(stock){
    if (stock<5) {
        throw new Quant("Out of stock")
    }     
}

function amtReq(a){
    try {
        checkQuant(stock)
        stock = stock - a
        console.log("stock is :"+stock);
        
    } catch (error) {
        console.log(error.name+" "+error.message);
        
    }
}

amtReq(3)
amtReq(5)
amtReq(1)
var Student = /** @class */ (function () {
    function Student(name, studentId, grade, address) {
        this.name = name;
        this.address = address;
        this.studentId = studentId;
        this.grade = grade;
    }
    Student.prototype.displayInfo = function () {
        console.log(this.name + " " + this.studentId + " " + this.grade + " " + this.address);
    };
    return Student;
}());
var s = new Student("tejas", 1, "A", "borivali");
s.displayInfo();

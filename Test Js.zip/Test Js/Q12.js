var Course = /** @class */ (function () {
    function Course(courseName, courseCode, instructor) {
        this.instructor = instructor;
        this.courseCode = courseCode;
        this.courseName = courseName;
    }
    return Course;
}());
var c = new Course("comp", 1, "tj");
console.log(c.courseCode);

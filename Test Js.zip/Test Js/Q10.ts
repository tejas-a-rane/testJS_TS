class Student {
    name : string
    studentId : number
    grade : string
    address : string

    constructor(name:string,studentId:number,grade:string,address:string){
        this.name = name
        this.address =address
        this.studentId = studentId
        this.grade = grade
    }

    displayInfo() : void{
        console.log(this.name+" "+this.studentId+" "+this.grade+" "+this.address);
    }

}

const s = new Student("tejas",1,"A","borivali")
s.displayInfo()

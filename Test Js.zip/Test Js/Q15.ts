function getStudnetInfo<P>(data : P) :P{
    return data
}

console.log(getStudnetInfo(10));

class Student {
    name : string
    studentId : number
    constructor(name:string,studentId:number){
        this.name = name
        this.studentId = studentId
        
    }

}
class School{
    static totalStudents : number
    studentList :Student[]
    
    addStudent(student:Student) : void{
        this.studentList.push(student);
        School.totalStudents++;
    }
    showCount() : void{
        console.log(this.studentList);
    }
}

const s1= new Student("tejas",1)
const s2= new Student("teja",2)
const s3= new Student("tejs",3)

const School1 = new School()

School1.addStudent(s1)
School1.addStudent(s2)
School1.addStudent(s3)

School1.showCount()

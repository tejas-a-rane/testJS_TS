class Course{
    courseName : string
    courseCode : number
    instructor : string
    constructor(courseName : string,courseCode : number,instructor : string){
        this.instructor = instructor
        this.courseCode = courseCode
        this.courseName = courseName    
        
    }
}

const c = new Course("comp",1,"tj");

console.log(c.courseCode);

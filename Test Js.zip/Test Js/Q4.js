class Emp{
    name
    id
    salary

     constructor(name,id,salary){
        this.id =id
        this.salary=salary
        this.name = name
     }   
    displayInfo(){
        console.log(this.id+" "+this.name+" "+this.salary);
    }


}
 const e1 = new Emp("tj",1,1234)
 e1.displayInfo()
const person ={
    name : "tejas", 
    age : "21",
    gender : M
}

console.log(person.name);

var Student = /** @class */ (function () {
    function Student(name, studentId) {
        this.name = name;
        this.studentId = studentId;
    }
    return Student;
}());
var School = /** @class */ (function () {
    function School() {
    }
    School.prototype.addStudent = function (student) {
        this.studentList.push(student);
        School.totalStudents++;
    };
    School.prototype.showCount = function () {
        console.log(this.studentList);
    };
    return School;
}());
var s1 = new Student("tejas", 1);
var s2 = new Student("teja", 2);
var s3 = new Student("tejs", 3);
var School1 = new School();
School1.addStudent(s1);
School1.addStudent(s2);
School1.addStudent(s3);
School1.showCount();

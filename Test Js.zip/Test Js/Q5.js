const prodarr = ["laptop","pc"]

const [p1,p2] = prodarr

console.log(p1);
console.log(p2);


const prodobj = {
    name: "Tv",
    price : "1000"
}

const {name,price} = prodobj

console.log(name);

interface Attendance{
    markAttendance() : void
}
class Student implements Attendance{
    name : string
    studentId : number
    attendance : number = 0
    constructor(name:string,studentId:number){
        this.name = name
        this.studentId = studentId
        
    }
    markAttendance(): void {
        this.attendance++
    }
    showAttendance(): void{
        console.log(this.attendance);
        
    }

}

const s1 = new Student("tejas",1)

s1.markAttendance()
s1.markAttendance()
s1.markAttendance()
s1.showAttendance()
const arr =[10,20,30,40]

const total = arr.reduce((arr,sum)=>{
    return arr + sum
},0)

console.log(total);
